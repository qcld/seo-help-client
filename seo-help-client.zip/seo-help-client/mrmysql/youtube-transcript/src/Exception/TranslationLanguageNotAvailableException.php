<?php

namespace MrMySQL\YoutubeTranscript\Exception;

use Exception;

class TranslationLanguageNotAvailableException extends Exception implements YoutubeTranscriptExceptionInterface
{

}
