<?php

namespace MrMySQL\YoutubeTranscript\Exception;

use Exception;

class FailedToCreateConsentCookieException extends Exception implements YoutubeTranscriptExceptionInterface
{

}
