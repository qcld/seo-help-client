<?php

namespace MrMySQL\YoutubeTranscript\Exception;

use Exception;

class NoTranscriptAvailableException extends Exception implements YoutubeTranscriptExceptionInterface
{

}
