<?php

namespace MrMySQL\YoutubeTranscript\Exception;

class PoTokenRequiredException extends \Exception implements YoutubeTranscriptExceptionInterface
{

}
