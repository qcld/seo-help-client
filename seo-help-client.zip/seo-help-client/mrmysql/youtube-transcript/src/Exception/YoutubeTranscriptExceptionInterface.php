<?php

namespace MrMySQL\YoutubeTranscript\Exception;

use Exception;

interface YoutubeTranscriptExceptionInterface
{
}
