<?php

namespace MrMySQL\YoutubeTranscript\Exception;

use Exception;

class YouTubeRequestFailedException extends Exception implements YoutubeTranscriptExceptionInterface
{

}
