<?php

namespace MrMySQL\YoutubeTranscript\Exception;

use Exception;

class NoTranscriptFoundException extends Exception
{

}
