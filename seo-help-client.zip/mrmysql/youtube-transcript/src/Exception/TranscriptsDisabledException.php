<?php

namespace MrMySQL\YoutubeTranscript\Exception;

use Exception;

class TranscriptsDisabledException extends Exception implements YoutubeTranscriptExceptionInterface
{

}
