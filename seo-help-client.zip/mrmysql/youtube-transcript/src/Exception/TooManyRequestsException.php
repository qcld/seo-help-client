<?php

namespace MrMySQL\YoutubeTranscript\Exception;

use Exception;

class TooManyRequestsException extends Exception implements YoutubeTranscriptExceptionInterface
{

}
