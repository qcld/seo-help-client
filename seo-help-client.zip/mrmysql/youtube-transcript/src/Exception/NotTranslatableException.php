<?php

namespace MrMySQL\YoutubeTranscript\Exception;

use Exception;

class NotTranslatableException extends Exception implements YoutubeTranscriptExceptionInterface
{

}
