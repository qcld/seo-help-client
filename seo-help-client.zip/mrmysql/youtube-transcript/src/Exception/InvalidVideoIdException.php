<?php

namespace MrMySQL\YoutubeTranscript\Exception;

use Exception;

class InvalidVideoIdException extends Exception implements YoutubeTranscriptExceptionInterface
{

}
