<?php

namespace MrMySQL\YoutubeTranscript\Exception;

use Exception;

class VideoUnavailableException extends Exception implements YoutubeTranscriptExceptionInterface
{

}
